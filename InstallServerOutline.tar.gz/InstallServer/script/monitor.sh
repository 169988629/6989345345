#!/bin/bash

if [ $# -eq 0 ]; then
	echo "###################"
	echo "invalid para,usage:"
	echo "-r: run project"
	echo "-k: kill project"
	echo "###################"
fi

ps_num=`ps -ef | grep v2ray | grep -v grep | wc -l`
if [ $ps_num -lt 1 -a "$1" == "-r" ]; then
	nohup /home/run_bin/v2ray -config /home/run_bin/config-vps.json 1>/dev/null 2>&1 &
	timenew=`date`
	echo "$timenew: Run /home/v2ray"
fi

if [ $ps_num -gt 0 -a "$1" == "-k" ]; then
	killall v2ray
	timenew=`date`
	echo "$timenew: Kill /home/v2ray"
fi
